from math import sqrt


def prod_non_zero_diag(x):
    """Compute product of nonzero elements from matrix diagonal.

    input:
    x -- 2-d numpy array
    output:
    product -- integer number


    Not vectorized implementation.
    """

    n = min(len(x), len(x[0]))
    ans = 1
    for i in range(n):
        if x[i][i] != 0:
            ans *= x[i][i]
    return ans


def are_multisets_equal(x, y):
    """Return True if both vectors create equal multisets.

    input:
    x, y -- 1-d numpy arrays
    output:
    True if multisets are equal, False otherwise -- boolean

    Not vectorized implementation.
    """

    x.sort()
    y.sort()
    return x == y


def max_after_zero(x):
    """Find max element after zero in array.

    input:
    x -- 1-d numpy array
    output:
    maximum element after zero -- integer number

    Not vectorized implementation.
    """

    n = len(x)
    ans = 0
    for i in range(1, n):
        if x[i - 1] == 0:
            ans = max(ans, x[i])
    return ans


def convert_image(img, coefs):
    """Sum up image channels with weights from coefs array

    input:
    img -- 3-d numpy array (H x W x 3)
    coefs -- 1-d numpy array (length 3)
    output:
    img -- 2-d numpy array

    Not vectorized implementation.
    """

    height = len(img)
    width = len(img[0])
    num = len(img[0][0])
    a = [[0 for i in range(width)] for j in range(height)]
    for i in range(height):
        for j in range(width):
            sum = 0
            for g in range(num):
                sum += img[i][j][g] * coefs[g]
            a[i][j] = sum
    return a


def run_length_encoding(x):
    """Make run-length encoding.

    input:
    x -- 1-d numpy array
    output:
    elements, counters -- integer iterables

    Not vectorized implementation.
    """

    n = len(x)
    a = [1]
    b = [x[0]]
    for i in range(1, n):
        if x[i] == x[i - 1]:
            a[-1] += 1
        else:
            a.append(1)
            b.append(x[i])
    return (b, a)


def pairwise_distance(x, y):
    """Return pairwise object distance.

    input:
    x, y -- 2d numpy arrays
    output:
    distance array -- 2d numpy array

    Not vectorized implementation.
    """

    n = len(x)
    m = len(y)
    a = [[0 for i in range(m)] for j in range(n)]
    k = len(x[0])
    for i in range(n):
        for j in range(m):
            sum = 0
            for g in range(k):
                sum += (x[i][g] - y[j][g])**2
            a[i][j] = sqrt(sum)
    return a