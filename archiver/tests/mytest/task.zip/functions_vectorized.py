import numpy as np
from math import sqrt


def prod_non_zero_diag_vectorized(x):
    """Compute product of nonzero elements from matrix diagonal.

    input:
    x -- 2-d numpy array
    output:
    product -- integer number


    Vectorized implementation.
    """
    b = x.diagonal()
    b = b[b.nonzero()]
    return b.prod()
    


def are_multisets_equal_vectorized(x, y):
    """Return True if both vectors create equal multisets.

    input:
    x, y -- 1-d numpy arrays
    output:
    True if multisets are equal, False otherwise -- boolean

    Vectorized implementation.
    """

    x.sort()
    y.sort()
    return np.array_equal(x, y)


def max_after_zero_vectorized(x):
    """Find max element after zero in array.

    input:
    x -- 1-d numpy array
    output:
    maximum element after zero -- integer number

    Vectorized implementation.
    """

    n = len(x)
    y = np.where(x == 0)[0]
    y += 1
    y = y[np.where(y < n)[0]]
    a = x[y]
    return a.max(initial=0)


def convert_image_vectorized(img, coefs):
    """Sum up image channels with weights from coefs array

    input:
    img -- 3-d numpy array (H x W x 3)
    coefs -- 1-d numpy array (length 3)
    output:
    img -- 2-d numpy array

    Vectorized implementation.
    """

    a = (img * coefs).sum(axis=2)
    return a


def run_length_encoding_vectorized(x):
    """Make run-length encoding.

    input:
    x -- 1-d numpy array
    output:
    elements, counters -- integer iterables

    Vectorized implementation.
    """

    b = x[1:] != x[:-1]
    b = np.append(np.where(b != 0)[0], len(x) - 1)
    return (x[b], np.diff(np.concatenate([[-1], b])))


def pairwise_distance_vectorized(x, y):
    """Return pairwise object distance.

    input:
    x, y -- 2d numpy arrays
    output:
    distance array -- 2d numpy array

    Vctorized implementation.
    """

    a = np.add.outer((x**2).sum(axis=1), (y**2).sum(axis=1))
    b = x.dot(y.T) * 2
    return np.sqrt(a - b)
